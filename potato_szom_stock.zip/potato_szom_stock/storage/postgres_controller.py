"""
PostgreSQL storage controller.

This module defines a `PostgresController` class that can connect to
a PostgreSQL database and perform basic operations.  If the
`psycopg2` package is unavailable, the controller will operate on
an in‑memory dictionary instead.  The goal is to provide a common
interface for storing and retrieving arbitrary data in a relational
database environment.
"""

from typing import Any, Optional

try:
    import psycopg2  # type: ignore
    _HAS_PG = True
except ImportError:
    psycopg2 = None  # type: ignore
    _HAS_PG = False


class PostgresController:
    def __init__(self, dsn: str) -> None:
        self._dsn = dsn
        self._conn: Optional[Any] = None
        self._store: dict[str, Any] = {}

    def connect(self) -> None:
        """Establish a connection to the PostgreSQL server."""
        if _HAS_PG:
            self._conn = psycopg2.connect(self._dsn)
        else:
            self._conn = None

    def store_data(self, key: str, value: Any) -> None:
        """Store data in a simple key/value table."""
        if self._conn is not None:
            assert _HAS_PG and self._conn is not None
            with self._conn.cursor() as cur:
                cur.execute(
                    "CREATE TABLE IF NOT EXISTS kv_store (key TEXT PRIMARY KEY, value TEXT);")
                cur.execute(
                    "INSERT INTO kv_store (key, value) VALUES (%s, %s) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;",
                    (key, str(value)),
                )
                self._conn.commit()
        else:
            self._store[key] = value

    def get_data(self, key: str) -> Optional[Any]:
        """Retrieve data for the given key."""
        if self._conn is not None:
            assert _HAS_PG and self._conn is not None
            with self._conn.cursor() as cur:
                cur.execute("SELECT value FROM kv_store WHERE key = %s;", (key,))
                row = cur.fetchone()
                return row[0] if row else None
        return self._store.get(key)
