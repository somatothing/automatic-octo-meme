"""
Supabase storage controller.

Supabase is a backend‑as‑a‑service platform providing a hosted
PostgreSQL database with realtime subscriptions and API access.  This
controller demonstrates how you might interact with Supabase from
Python.  If the `supabase` package is not installed, it falls back
to an in‑memory dictionary for demonstration purposes.
"""

from typing import Any, Optional

try:
    from supabase import create_client  # type: ignore
    _HAS_SUPABASE = True
except ImportError:
    create_client = None  # type: ignore
    _HAS_SUPABASE = False


class SupabaseController:
    def __init__(self, url: str, key: str) -> None:
        self._url = url
        self._key = key
        self._client: Optional[Any] = None
        self._store: dict[str, Any] = {}

    def connect(self) -> None:
        """Initialize the Supabase client."""
        if _HAS_SUPABASE:
            self._client = create_client(self._url, self._key)
        else:
            self._client = None

    def store_data(self, table: str, key: str, value: Any) -> None:
        """Insert or update a row in the given table."""
        if self._client is not None:
            assert _HAS_SUPABASE and self._client is not None
            data = {"key": key, "value": value}
            # Upsert by key
            self._client.table(table).upsert(data).execute()
        else:
            self._store.setdefault(table, {})[key] = value

    def get_data(self, table: str, key: str) -> Optional[Any]:
        """Retrieve a value from the given table."""
        if self._client is not None:
            assert _HAS_SUPABASE and self._client is not None
            response = (
                self._client.table(table)
                .select("value")
                .eq("key", key)
                .single()
                .execute()
            )
            return response.data.get("value") if response.data else None
        return self._store.get(table, {}).get(key)
