"""
Redis storage controller.

This module provides a simple interface to interact with a Redis
database.  It defines a `RedisController` class with methods to
connect to a Redis instance, store key‑value pairs, and retrieve
values.  The implementation uses the optional `redis` Python package
when available.  If the `redis` package cannot be imported (e.g. in
this environment), it falls back to an in‑memory dictionary.
"""

from typing import Any, Optional

try:
    import redis  # type: ignore
    _HAS_REDIS = True
except ImportError:
    redis = None  # type: ignore
    _HAS_REDIS = False


class RedisController:
    def __init__(self, url: str) -> None:
        self._url = url
        self._client: Optional[Any] = None
        self._store: dict[str, Any] = {}  # fallback storage

    def connect(self) -> None:
        """Connect to the Redis server.

        If the `redis` package is available, a real client will be
        created.  Otherwise an in‑memory fallback is used.
        """
        if _HAS_REDIS:
            self._client = redis.from_url(self._url)
        else:
            self._client = None

    def store_data(self, key: str, value: Any) -> None:
        """Store a value under the given key."""
        if self._client is not None:
            assert _HAS_REDIS and self._client is not None
            self._client.set(key, value)
        else:
            self._store[key] = value

    def get_data(self, key: str) -> Optional[Any]:
        """Retrieve a value by key."""
        if self._client is not None:
            assert _HAS_REDIS and self._client is not None
            return self._client.get(key)
        return self._store.get(key)
